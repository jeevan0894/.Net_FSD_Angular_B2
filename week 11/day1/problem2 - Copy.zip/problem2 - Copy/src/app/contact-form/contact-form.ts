import { Component } from '@angular/core';
import { Contact } from './model/Contact.model';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-contact-form',
  imports: [CommonModule,FormsModule],
  templateUrl: './contact-form.html',
  styleUrl: './contact-form.css',
})
export class ContactForm {
contacts :Contact[]=[];
newContact:Contact={
  contactId:0,
  name:'',
  email:'',
  phone:'',
  isActive:false
};

private idcounter=1;
onSubmit(form:any){
  if(form.valid){
    const contact:Contact={
      ...this.newContact,
      contactId: this.idcounter++
    };
    this.contacts.push(contact);
    form.resetForm();
  }
}
}
