import { Component } from '@angular/core';
import { contact } from './model/contact.model';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-contact',
  imports: [CommonModule],
  templateUrl: './contact.html',
  styleUrl: './contact.css',
})
export class ContactDetails {
  contacts :contact[]=[
    {contactId:1,
      name:'jeevan',
      email:'jeevan@gmail.com',
      phone:'123456789',
      isActive:true
    },
    {
      contactId:2,
      name:'sai',
      email:'sai@gmail.com',
      phone:'1654986165',
      isActive:true
    },
    {
      contactId:3,
      name:'kiran',
      email:'kirnam@gmail.com',
      phone:'12345689',
      isActive:false


    }
  ];
}
