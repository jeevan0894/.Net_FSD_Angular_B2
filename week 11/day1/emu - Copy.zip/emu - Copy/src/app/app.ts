import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ContactDetails } from './contact/contact';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,ContactDetails],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('emu');
}
