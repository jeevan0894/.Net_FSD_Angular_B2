using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using ContactManagement.API.DTOs;
using ContactManagement.API.Exceptions;
using ContactManagement.DAL.DbContext;
using ContactManagement.DAL.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

namespace ContactManagement.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IConfiguration _configuration;
        private readonly PasswordHasher<UserInfo> _passwordHasher;
        private readonly ILogger<AuthController> _logger;

        public AuthController(
            AppDbContext context,
            IConfiguration configuration,
            PasswordHasher<UserInfo> passwordHasher,
            ILogger<AuthController> logger)
        {
            _context = context;
            _configuration = configuration;
            _passwordHasher = passwordHasher;
            _logger = logger;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register(RegisterDto dto)
        {
            if (!ModelState.IsValid)
            {
                throw new BadRequestException("Invalid registration request.");
            }

            if (dto.Role != "Admin" && dto.Role != "User")
            {
                throw new BadRequestException("Role must be Admin or User.");
            }

            var exists = await _context.Users.AnyAsync(u => u.EmailId == dto.EmailId);
            if (exists)
            {
                throw new BadRequestException("User already exists.");
            }

            var user = new UserInfo
            {
                EmailId = dto.EmailId,
                Role = dto.Role
            };

            user.PasswordHash = _passwordHasher.HashPassword(user, dto.Password);

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            _logger.LogInformation("New user registered: {EmailId} with role {Role}", dto.EmailId, dto.Role);

            return Ok(new { message = "User registered successfully." });
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginDto dto)
        {
            _logger.LogInformation("Login attempt for {EmailId}", dto.EmailId);

            if (!ModelState.IsValid)
            {
                throw new BadRequestException("Invalid login request.");
            }

            var user = await _context.Users.FirstOrDefaultAsync(u => u.EmailId == dto.EmailId);
            if (user == null)
            {
                _logger.LogWarning("Failed login attempt for {EmailId}", dto.EmailId);
                throw new BadRequestException("Invalid credentials.");
            }

            var result = _passwordHasher.VerifyHashedPassword(user, user.PasswordHash, dto.Password);
            if (result == PasswordVerificationResult.Failed)
            {
                _logger.LogWarning("Failed login attempt for {EmailId}", dto.EmailId);
                throw new BadRequestException("Invalid credentials.");
            }

            var claims = new[]
            {
                new Claim(ClaimTypes.Email, user.EmailId),
                new Claim(ClaimTypes.Role, user.Role)
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]!));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt:Issuer"],
                audience: _configuration["Jwt:Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddHours(1),
                signingCredentials: creds
            );

            var jwt = new JwtSecurityTokenHandler().WriteToken(token);

            _logger.LogInformation("Successful login for {EmailId}", dto.EmailId);

            return Ok(new
            {
                token = jwt,
                email = user.EmailId,
                role = user.Role
            });
        }
    }
}
