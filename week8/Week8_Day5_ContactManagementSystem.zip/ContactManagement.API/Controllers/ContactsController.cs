using ContactManagement.API.Exceptions;
using ContactManagement.DAL.Models;
using ContactManagement.DAL.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ContactManagement.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class ContactsController : ControllerBase
    {
        private readonly IContactRepository _repository;
        private readonly ILogger<ContactsController> _logger;

        public ContactsController(IContactRepository repository, ILogger<ContactsController> logger)
        {
            _repository = repository;
            _logger = logger;
        }

        [HttpGet]
        [Authorize(Roles = "Admin,User")]
        public async Task<IActionResult> GetAllContacts()
        {
            var contacts = await _repository.GetAllAsync();
            return Ok(contacts);
        }

        [HttpGet("{id}")]
        [Authorize(Roles = "Admin,User")]
        public async Task<IActionResult> GetContactById(int id)
        {
            var contact = await _repository.GetByIdAsync(id);

            if (contact == null)
            {
                throw new ContactNotFoundException($"Contact with ID {id} not found.");
            }

            return Ok(contact);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> CreateContact([FromBody] ContactInfo contact)
        {
            if (!ModelState.IsValid)
            {
                throw new BadRequestException("Invalid contact data.");
            }

            var created = await _repository.AddAsync(contact);
            _logger.LogInformation("Contact created: {ContactId} - {Email}", created.ContactId, created.EmailId);

            return CreatedAtAction(nameof(GetContactById), new { id = created.ContactId }, created);
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateContact(int id, [FromBody] ContactInfo contact)
        {
            if (!ModelState.IsValid)
            {
                throw new BadRequestException("Invalid contact data.");
            }

            var updated = await _repository.UpdateAsync(id, contact);
            if (!updated)
            {
                throw new ContactNotFoundException($"Contact with ID {id} not found.");
            }

            _logger.LogInformation("Contact updated: {ContactId}", id);

            return Ok(new { message = "Contact updated successfully." });
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteContact(int id)
        {
            var deleted = await _repository.DeleteAsync(id);
            if (!deleted)
            {
                throw new ContactNotFoundException($"Contact with ID {id} not found.");
            }

            _logger.LogInformation("Contact deleted: {ContactId}", id);

            return Ok(new { message = "Contact deleted successfully." });
        }
    }
}
