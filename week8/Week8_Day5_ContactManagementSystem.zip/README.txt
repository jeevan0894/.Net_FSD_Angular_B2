Week-8 Day-5 - Contact Management (Exception Handling & Logging)

Included:
- 2-layer solution
- EF Core Code First
- JWT Authentication
- Role-based Authorization
- Global Exception Middleware
- Custom Exceptions
- Structured Console Logging with ILogger
- Consistent Error Response

Error Response Format:
{
  "message": "Something went wrong",
  "statusCode": 500,
  "timestamp": "2026-04-05T10:00:00"
}

Logging:
- Contact created
- Contact updated
- Contact deleted
- User login attempts
- Unhandled exceptions

Default Users:
- admin@example.com / Admin@123
- user@example.com / User@123
