Week-8 Day-4 - Contact Management (Web API + EF Core + JWT Authentication)

Solution Structure:
- ContactManagement.DAL
  - Models
  - DbContext
  - Repository
- ContactManagement.API
  - Controllers
  - DTOs
  - Program.cs

Features:
- EF Core Code First
- SQL Server LocalDB
- Repository Pattern
- Dependency Injection
- JWT Authentication
- Role-Based Authorization
- Admin/User roles
- CRUD for ContactInfo
- Company and Department relationships
- Swagger enabled

Default Users:
- admin@example.com / Admin@123
- user@example.com / User@123

Role Access:
- Admin: Full CRUD
- User: Read-only

How to test:
1. Run the API project
2. Open Swagger
3. Login using /api/auth/login
4. Copy token
5. Click Authorize
6. Enter: Bearer <token>
7. Test contact endpoints
