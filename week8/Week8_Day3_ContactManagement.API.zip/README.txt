Week-8 Day-3 - Contact Management API (In-Memory)

Features:
- ASP.NET Core Web API (.NET 8)
- Static List<ContactInfo> as temporary storage
- Repository Pattern
- Dependency Injection
- Async Task-based methods
- RESTful CRUD endpoints
- Swagger enabled

Project Structure:
- Controllers
- Models
- DataAccess
- Program.cs
- appsettings.json
- ContactManagement.API.csproj

Endpoints:
GET    /api/contacts
GET    /api/contacts/{id}
POST   /api/contacts
PUT    /api/contacts/{id}
DELETE /api/contacts/{id}

Notes:
- ContactId is auto-generated in repository.
- No database / no EF Core used.
- Direct data handling is not done inside controller.
