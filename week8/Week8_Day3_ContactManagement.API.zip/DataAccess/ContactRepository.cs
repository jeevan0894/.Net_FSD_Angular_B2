using ContactManagement.API.Models;

namespace ContactManagement.API.DataAccess
{
    public class ContactRepository : IContactRepository
    {
        public static List<ContactInfo> contacts = new List<ContactInfo>
        {
            new ContactInfo
            {
                ContactId = 1,
                FirstName = "Rahul",
                LastName = "Sharma",
                EmailId = "rahul@example.com",
                MobileNo = 9876543210,
                Designation = "Developer",
                CompanyId = 1,
                DepartmentId = 101
            },
            new ContactInfo
            {
                ContactId = 2,
                FirstName = "Aisha",
                LastName = "Khan",
                EmailId = "aisha@example.com",
                MobileNo = 9123456780,
                Designation = "HR Executive",
                CompanyId = 2,
                DepartmentId = 102
            }
        };

        public Task<IEnumerable<ContactInfo>> GetAllAsync()
        {
            return Task.FromResult<IEnumerable<ContactInfo>>(contacts);
        }

        public Task<ContactInfo?> GetByIdAsync(int id)
        {
            var contact = contacts.FirstOrDefault(c => c.ContactId == id);
            return Task.FromResult(contact);
        }

        public Task<ContactInfo> AddAsync(ContactInfo contact)
        {
            int nextId = contacts.Count == 0 ? 1 : contacts.Max(c => c.ContactId) + 1;
            contact.ContactId = nextId;
            contacts.Add(contact);
            return Task.FromResult(contact);
        }

        public Task<bool> UpdateAsync(int id, ContactInfo contact)
        {
            var existingContact = contacts.FirstOrDefault(c => c.ContactId == id);
            if (existingContact == null)
            {
                return Task.FromResult(false);
            }

            existingContact.FirstName = contact.FirstName;
            existingContact.LastName = contact.LastName;
            existingContact.EmailId = contact.EmailId;
            existingContact.MobileNo = contact.MobileNo;
            existingContact.Designation = contact.Designation;
            existingContact.CompanyId = contact.CompanyId;
            existingContact.DepartmentId = contact.DepartmentId;

            return Task.FromResult(true);
        }

        public Task<bool> DeleteAsync(int id)
        {
            var existingContact = contacts.FirstOrDefault(c => c.ContactId == id);
            if (existingContact == null)
            {
                return Task.FromResult(false);
            }

            contacts.Remove(existingContact);
            return Task.FromResult(true);
        }
    }
}
