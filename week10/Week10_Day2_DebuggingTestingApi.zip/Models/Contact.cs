using System.ComponentModel.DataAnnotations;

namespace Week10_Day2_DebuggingTestingApi.Models
{
    public class Contact
    {
        public int Id { get; set; }
        [Required]
        public string Name { get; set; } = string.Empty;
        [Required, EmailAddress]
        public string Email { get; set; } = string.Empty;
        [Required]
        public string Phone { get; set; } = string.Empty;
    }
}
