using Week10_Day2_DebuggingTestingApi.Models;
using Week10_Day2_DebuggingTestingApi.Repositories;

namespace Week10_Day2_DebuggingTestingApi.Services
{
    public class ContactService : IContactService
    {
        private readonly IContactRepository repository;
        private readonly ILogger<ContactService> logger;

        public ContactService(IContactRepository repository, ILogger<ContactService> logger)
        {
            this.repository = repository;
            this.logger = logger;
        }

        public async Task<List<Contact>> GetAllAsync()
        {
            logger.LogInformation("Fetching all contacts.");
            return await repository.GetAllAsync();
        }

        public async Task<Contact?> GetByIdAsync(int id)
        {
            logger.LogInformation("Fetching contact by id: {Id}", id);
            return await repository.GetByIdAsync(id);
        }

        public async Task<Contact> AddAsync(Contact contact)
        {
            ValidateContact(contact);
            logger.LogInformation("Adding contact: {Name}", contact.Name);
            return await repository.AddAsync(contact);
        }

        public async Task<bool> UpdateAsync(int id, Contact contact)
        {
            ValidateContact(contact);
            logger.LogInformation("Updating contact: {Id}", id);
            return await repository.UpdateAsync(id, contact);
        }

        public async Task<bool> DeleteAsync(int id)
        {
            logger.LogInformation("Deleting contact: {Id}", id);
            return await repository.DeleteAsync(id);
        }

        private static void ValidateContact(Contact contact)
        {
            ArgumentNullException.ThrowIfNull(contact);

            if (string.IsNullOrWhiteSpace(contact.Name))
                throw new ArgumentException("Name is required.");
            if (string.IsNullOrWhiteSpace(contact.Email))
                throw new ArgumentException("Email is required.");
            if (string.IsNullOrWhiteSpace(contact.Phone))
                throw new ArgumentException("Phone is required.");
        }
    }
}
