using Microsoft.AspNetCore.Mvc;
using Week10_Day2_DebuggingTestingApi.Models;
using Week10_Day2_DebuggingTestingApi.Services;

namespace Week10_Day2_DebuggingTestingApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ContactsController : ControllerBase
    {
        private readonly IContactService service;

        public ContactsController(IContactService service)
        {
            this.service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await service.GetAllAsync());
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            var contact = await service.GetByIdAsync(id);
            return contact is null
                ? NotFound(new { message = $"Contact with id {id} not found." })
                : Ok(contact);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Contact contact)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var created = await service.AddAsync(contact);
            return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, [FromBody] Contact contact)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            bool updated = await service.UpdateAsync(id, contact);
            return updated
                ? Ok(new { message = "Contact updated successfully." })
                : NotFound(new { message = $"Contact with id {id} not found." });
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            bool deleted = await service.DeleteAsync(id);
            return deleted
                ? Ok(new { message = "Contact deleted successfully." })
                : NotFound(new { message = $"Contact with id {id} not found." });
        }
    }
}
