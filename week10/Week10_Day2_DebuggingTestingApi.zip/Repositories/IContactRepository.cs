using Week10_Day2_DebuggingTestingApi.Models;

namespace Week10_Day2_DebuggingTestingApi.Repositories
{
    public interface IContactRepository
    {
        Task<List<Contact>> GetAllAsync();
        Task<Contact?> GetByIdAsync(int id);
        Task<Contact> AddAsync(Contact contact);
        Task<bool> UpdateAsync(int id, Contact contact);
        Task<bool> DeleteAsync(int id);
    }
}
