using Week10_Day2_DebuggingTestingApi.Models;

namespace Week10_Day2_DebuggingTestingApi.Repositories
{
    public class ContactRepository : IContactRepository
    {
        private static readonly List<Contact> contacts = new()
        {
            new Contact { Id = 1, Name = "Rahul", Email = "rahul@example.com", Phone = "9876543210" },
            new Contact { Id = 2, Name = "Aisha", Email = "aisha@example.com", Phone = "9123456780" }
        };

        public Task<List<Contact>> GetAllAsync() => Task.FromResult(contacts.ToList());

        public Task<Contact?> GetByIdAsync(int id)
        {
            Contact? contact = contacts.FirstOrDefault(c => c.Id == id);
            return Task.FromResult(contact);
        }

        public Task<Contact> AddAsync(Contact contact)
        {
            int nextId = contacts.Count == 0 ? 1 : contacts.Max(c => c.Id) + 1;
            contact.Id = nextId;
            contacts.Add(contact);
            return Task.FromResult(contact);
        }

        public Task<bool> UpdateAsync(int id, Contact contact)
        {
            Contact? existing = contacts.FirstOrDefault(c => c.Id == id);
            if (existing is null) return Task.FromResult(false);

            existing.Name = contact.Name;
            existing.Email = contact.Email;
            existing.Phone = contact.Phone;
            return Task.FromResult(true);
        }

        public Task<bool> DeleteAsync(int id)
        {
            Contact? existing = contacts.FirstOrDefault(c => c.Id == id);
            if (existing is null) return Task.FromResult(false);

            contacts.Remove(existing);
            return Task.FromResult(true);
        }
    }
}
