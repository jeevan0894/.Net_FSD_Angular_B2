const userName: string = "John";
let age: number = 25;
const email: string = "john@example.com";
const isSubscribed: boolean = true;

let city = "Mumbai";
let loginCount = 3;

age = age + 1;

const isEligibleForPremium: boolean = age > 18 && isSubscribed;
const profileMessage = `Hello ${userName}, you are ${age} years old and your email is ${email}.`;

console.log("User Name:", userName);
console.log("Age:", age);
console.log("Email:", email);
console.log("Is Subscribed:", isSubscribed);
console.log("City:", city);
console.log("Login Count:", loginCount);
console.log(profileMessage);
console.log("Eligible for Premium:", isEligibleForPremium);
