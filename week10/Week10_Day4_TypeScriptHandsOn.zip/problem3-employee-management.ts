class Employee {
    constructor(
        public id: number,
        protected name: string,
        private salary: number
    ) {}

    public getSalary(): number {
        return this.salary;
    }

    public setSalary(value: number): void {
        if (value > 0) {
            this.salary = value;
        } else {
            console.log("Salary must be greater than 0.");
        }
    }

    public displayDetails(): void {
        console.log(`Employee Id: ${this.id}, Name: ${this.name}, Salary: ${this.salary}`);
    }
}

class Manager extends Employee {
    constructor(
        id: number,
        name: string,
        salary: number,
        public teamSize: number
    ) {
        super(id, name, salary);
    }

    public override displayDetails(): void {
        console.log(`Manager Id: ${this.id}, Name: ${this.name}, Salary: ${this.getSalary()}, Team Size: ${this.teamSize}`);
    }
}

const employee = new Employee(1, "Rahul", 45000);
employee.displayDetails();
employee.setSalary(50000);
console.log("Updated Salary:", employee.getSalary());

const manager = new Manager(2, "Aisha", 70000, 8);
manager.displayDetails();
