function getWelcomeMessage(name: string): string {
    return `Welcome ${name}!`;
}

function getUserInfo(name: string, age?: number): string {
    return age !== undefined ? `${name} is ${age} years old.` : `${name}'s age is not provided.`;
}

function getSubscriptionStatus(name: string, isSubscribed: boolean = false): string {
    return isSubscribed ? `${name} is subscribed.` : `${name} is not subscribed.`;
}

function isEligibleForPremium(age: number): boolean {
    return age > 18;
}

const getAccountUpdate = (name: string): string => `Account updated for ${name}.`;

const notificationService = {
    appName: "ContactApp",
    sendNotification: (message: string): string => {
        return `[${notificationService.appName}] ${message}`;
    }
};

console.log(getWelcomeMessage("John"));
console.log(getUserInfo("Sara", 22));
console.log(getUserInfo("Aisha"));
console.log(getSubscriptionStatus("Rahul"));
console.log(getSubscriptionStatus("Rahul", true));
console.log("Eligible for premium:", isEligibleForPremium(25));
console.log(getAccountUpdate("Neha"));
console.log(notificationService.sendNotification("Subscription alert sent."));
