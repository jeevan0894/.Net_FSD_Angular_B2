Run with:
ts-node problem1-user-profile.ts
ts-node problem2-notification-functions.ts
ts-node problem3-employee-management.ts

Or compile with:
tsc
