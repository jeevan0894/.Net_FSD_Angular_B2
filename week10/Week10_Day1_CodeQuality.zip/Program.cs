using Week10_Day1_CodeQuality.Models;
using Week10_Day1_CodeQuality.Services;

IContactService contactService = new ContactService();

try
{
    contactService.AddContact(new Contact
    {
        Name = "Rahul Sharma",
        Email = "rahul@example.com",
        Phone = "9876543210"
    });

    contactService.AddContact(new Contact
    {
        Name = "Aisha Khan",
        Email = "aisha@example.com",
        Phone = "9123456780"
    });

    bool updated = contactService.UpdateContact(1, new Contact
    {
        Name = "Rahul Verma",
        Email = "rahul.verma@example.com",
        Phone = "9876500000"
    });

    Console.WriteLine(updated ? "Contact updated successfully." : "Contact not found.");

    foreach (var contact in contactService.GetAllContacts())
    {
        Console.WriteLine($"Id: {contact.Id}, Name: {contact.Name}, Email: {contact.Email}, Phone: {contact.Phone}");
    }

    bool deleted = contactService.DeleteContact(2);
    Console.WriteLine(deleted ? "Contact deleted successfully." : "Contact not found.");
}
catch (ArgumentException ex)
{
    Console.WriteLine($"Validation error: {ex.Message}");
}
