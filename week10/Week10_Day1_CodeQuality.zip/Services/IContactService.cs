using Week10_Day1_CodeQuality.Models;

namespace Week10_Day1_CodeQuality.Services
{
    public interface IContactService
    {
        void AddContact(Contact contact);
        bool UpdateContact(int id, Contact updatedContact);
        bool DeleteContact(int id);
        IReadOnlyList<Contact> GetAllContacts();
    }
}
