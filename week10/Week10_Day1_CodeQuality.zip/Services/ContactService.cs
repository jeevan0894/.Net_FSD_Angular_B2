using Week10_Day1_CodeQuality.Models;

namespace Week10_Day1_CodeQuality.Services
{
    public class ContactService : IContactService
    {
        private readonly List<Contact> contacts = new();
        private const int MinPhoneLength = 10;

        public void AddContact(Contact contact)
        {
            ValidateContact(contact);

            int nextId = contacts.Count == 0 ? 1 : contacts.Max(c => c.Id) + 1;
            contact.Id = nextId;
            contacts.Add(contact);
        }

        public bool UpdateContact(int id, Contact updatedContact)
        {
            ValidateContact(updatedContact);

            Contact? existingContact = contacts.FirstOrDefault(c => c.Id == id);
            if (existingContact is null)
            {
                return false;
            }

            existingContact.Name = updatedContact.Name;
            existingContact.Email = updatedContact.Email;
            existingContact.Phone = updatedContact.Phone;
            return true;
        }

        public bool DeleteContact(int id)
        {
            Contact? existingContact = contacts.FirstOrDefault(c => c.Id == id);
            if (existingContact is null)
            {
                return false;
            }

            contacts.Remove(existingContact);
            return true;
        }

        public IReadOnlyList<Contact> GetAllContacts()
        {
            return contacts.AsReadOnly();
        }

        private static void ValidateContact(Contact contact)
        {
            ArgumentNullException.ThrowIfNull(contact);

            if (string.IsNullOrWhiteSpace(contact.Name))
            {
                throw new ArgumentException("Name is required.");
            }

            if (string.IsNullOrWhiteSpace(contact.Email) || !contact.Email.Contains('@'))
            {
                throw new ArgumentException("Valid email is required.");
            }

            if (string.IsNullOrWhiteSpace(contact.Phone) || contact.Phone.Length < MinPhoneLength)
            {
                throw new ArgumentException("Phone must contain at least 10 characters.");
            }
        }
    }
}
